<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('venta_camisa', function (Blueprint $table) {
            $table->id();
            $table->integer("cantidad");
            $table->unsignedBigInteger("fk_camisa")->nullable(); 
            $table->foreign("fk_camisa")
                  ->references("id")->on("_camisetas")
                  ->onDelete("set null"); 
            $table->timestamps(); 
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('venta_camisa');
    }
};
