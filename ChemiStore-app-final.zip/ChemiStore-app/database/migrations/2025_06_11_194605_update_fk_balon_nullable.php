<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('venta_balon', function (Blueprint $table) {
            // Primero eliminar la clave foránea actual
            $table->dropForeign(['fk_balon']);
            
            // Cambiar la columna a nullable
            $table->unsignedBigInteger('fk_balon')->nullable()->change();
            
            // Crear la nueva clave foránea con onDelete('set null')
            $table->foreign('fk_balon')
                ->references('id')
                ->on('_balones')
                ->onDelete('set null');
        });
    }

    public function down(): void {
        Schema::table('venta_balon', function (Blueprint $table) {
            // Eliminar la clave foránea modificada
            $table->dropForeign(['fk_balon']);
            
            // Cambiar la columna a NOT NULL (no nullable)
            $table->unsignedBigInteger('fk_balon')->nullable(false)->change();
            
            // Restaurar la clave foránea sin onDelete('set null')
            $table->foreign('fk_balon')
                ->references('id')
                ->on('_balones');
        });
    }
};
