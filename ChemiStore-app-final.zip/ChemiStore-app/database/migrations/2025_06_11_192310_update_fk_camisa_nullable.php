<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('venta_camisa', function (Blueprint $table) {
            // Eliminar la clave foránea anterior
            $table->dropForeign(['fk_camisa']);

            // Hacer el campo nullable
            $table->unsignedBigInteger('fk_camisa')->nullable()->change();

            // Crear la nueva clave foránea con SET NULL
            $table->foreign('fk_camisa')
                ->references('id')
                ->on('_camisetas')
                ->onDelete('set null');
        });
    }

    public function down(): void {
        Schema::table('venta_camisa', function (Blueprint $table) {
            $table->dropForeign(['fk_camisa']);
            $table->unsignedBigInteger('fk_camisa')->nullable(false)->change();
            $table->foreign('fk_camisa')
                ->references('id')
                ->on('_camisetas');
        });
    }
};
