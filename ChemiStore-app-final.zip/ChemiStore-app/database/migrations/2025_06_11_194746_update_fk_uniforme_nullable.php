<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('venta_uniforme', function (Blueprint $table) {
            // Eliminar la clave foránea actual
            $table->dropForeign(['fk_uniforme']);

            // Cambiar la columna para que sea nullable
            $table->unsignedBigInteger('fk_uniforme')->nullable()->change();

            // Crear la nueva clave foránea con onDelete('set null')
            $table->foreign('fk_uniforme')
                ->references('id')
                ->on('_uniformes')
                ->onDelete('set null');
        });
    }

    public function down(): void {
        Schema::table('venta_uniforme', function (Blueprint $table) {
            // Eliminar la clave foránea modificada
            $table->dropForeign(['fk_uniforme']);

            // Volver a hacer la columna no nullable
            $table->unsignedBigInteger('fk_uniforme')->nullable(false)->change();

            // Restaurar la clave foránea sin onDelete('set null')
            $table->foreign('fk_uniforme')
                ->references('id')
                ->on('_uniformes');
        });
    }
};
