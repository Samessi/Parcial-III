<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('venta_balon', function (Blueprint $table) {
            $table->unsignedBigInteger('fk_detalle_venta')->nullable()->after('fk_balon');
            $table->foreign('fk_detalle_venta')->references('id')->on('detalle_ventas')->onDelete('cascade');
        });

        Schema::table('venta_uniforme', function (Blueprint $table) {
            // Solo agregamos la foreign key porque la columna ya existe
            $table->foreign('fk_detalle_venta')->references('id')->on('detalle_ventas')->onDelete('cascade');
        });

        Schema::table('venta_camisa', function (Blueprint $table) {
            $table->unsignedBigInteger('fk_detalle_venta')->nullable()->after('fk_camisa');
            $table->foreign('fk_detalle_venta')->references('id')->on('detalle_ventas')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::table('venta_balon', function (Blueprint $table) {
            $table->dropForeign(['fk_detalle_venta']);
        });

        Schema::table('venta_uniforme', function (Blueprint $table) {
            $table->dropForeign(['fk_detalle_venta']);
        });

        Schema::table('venta_camisa', function (Blueprint $table) {
            $table->dropForeign(['fk_detalle_venta']);
        });
    }
};
