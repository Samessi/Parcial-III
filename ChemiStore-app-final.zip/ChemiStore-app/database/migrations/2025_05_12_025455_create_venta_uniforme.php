<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('venta_uniforme', function (Blueprint $table) {
            $table->id();
            $table->integer("cantidad");
            $table->unsignedBigInteger("fk_uniforme")->nullable();
            $table->unsignedBigInteger('fk_detalle_venta')->nullable();
            
            $table->foreign("fk_uniforme")
                ->references("id")->on("_uniformes")
                ->onDelete("set null");

            $table->foreign('fk_detalle_venta')
                ->references('id')->on('detalle_ventas') // ajusta el nombre si es distinto
                ->onDelete('set null');
            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::table('venta_uniforme', function (Blueprint $table) {
            $table->dropForeign(['fk_uniforme']);
            $table->dropForeign(['fk_detalle_venta']);
        });
        Schema::dropIfExists('venta_uniforme');
    }
};
