<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Uniforme;
use App\Models\DetalleVenta;

class VentaUniforme extends Model
{
    protected $table = 'venta_uniforme';

    protected $fillable = [
        'cantidad',
        'fk_uniforme',
        'fk_detalle_venta', // si usas esta relación
    ];

    // Relación: una venta pertenece a un uniforme (producto)
    public function uniforme()
    {
        return $this->belongsTo(Uniforme::class, 'fk_uniforme')->withDefault([
            'Equipo_uniforme' => 'Uniforme eliminado',
            'Marca_uniforme' => '',
            'Tamaño_uniforme' => '',
            'Tipo_uniforme' => '',
            'Precio_uniforme' => 0,
            'imagen_url' => null,
        ]);
    }

    // Relación con detalle venta (cliente)
    public function detalleVenta()
    {
        return $this->belongsTo(DetalleVenta::class, 'fk_detalle_venta');
    }
}
