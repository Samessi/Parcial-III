<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Camiseta;
use App\Models\DetalleVenta;

class VentaCamisa extends Model
{
    protected $table = 'venta_camisa';

    protected $fillable = [
        'cantidad',
        'fk_camisa',
        'fk_detalle_venta',
    ];

    /**
     * Relación: una venta de camisa pertenece a una camiseta.
     * Si la camiseta fue eliminada (set null), devuelve un objeto vacío por defecto.
     */
    public function camiseta()
    {
        return $this->belongsTo(Camiseta::class, 'fk_camisa')->withDefault([
            'Equipo_camiseta' => 'Camiseta eliminada',
            'Marca_camiseta' => '',
            'Tamaño_camiseta' => '',
            'Tipo_camiseta' => '',
            'Precio_camiseta' => 0,
            'imagen_url' => null,
        ]);
    }

    /**
     * Relación: una venta de camisa pertenece a un detalle de venta.
     */
    public function detalleVenta()
    {
        return $this->belongsTo(DetalleVenta::class, 'fk_detalle_venta');
    }
}
