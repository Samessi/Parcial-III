<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\VentaCamisa;

class Camiseta extends Model
{
    use HasFactory;

    protected $table = '_camisetas';

    protected $fillable = [
        'Equipo_camiseta',
        'Marca_camiseta',
        'Tamaño_camiseta',
        'Tipo_camiseta',
        'Precio_camiseta',
        'imagen_url',
    ];

    /**
     * Relación: una camiseta puede tener muchas ventas.
     */
    public function ventas()
    {
        return $this->hasMany(VentaCamisa::class, 'fk_camisa');
    }
}
