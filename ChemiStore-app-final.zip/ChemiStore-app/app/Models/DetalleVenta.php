<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleVenta extends Model
{
    // Indicar la tabla (opcional si sigue la convención plural)
    protected $table = 'detalle_ventas';

    // Campos que puedes asignar masivamente
    protected $fillable = [
        'nombre',
        'email',
        'telefono',
        'direccion',
    ];

    // Relación 1 a 1 con VentaCamisa
    public function ventaCamisa()
    {
        return $this->hasOne(VentaCamisa::class, 'fk_detalle_venta');
    }

    // Relación 1 a 1 con VentaBalon
    public function ventaBalon()
    {
        return $this->hasOne(VentaBalon::class, 'fk_detalle_venta');
    }

    // Relación 1 a 1 con VentaUniforme
    public function ventaUniforme()
    {
        return $this->hasOne(VentaUniforme::class, 'fk_detalle_venta');
    }
}
