<?php
namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Usuario extends Authenticatable
{
    protected $table = 'usuarios';  // Le decimos que esta clase usa la tabla 'usuarios'

    protected $fillable = [
        'Nombre', 'Apellido', 'Telefono', 'Correo', 'password',
    ];

    protected $hidden = ['password', 'remember_token'];
}
