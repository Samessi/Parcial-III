<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Usuario;  // Cambiar a tu modelo de usuario real

class Cart extends Model
{
    protected $table = 'carts';

    protected $fillable = [
        'user_id',
        'producto_id',
        'tipo_producto',
        'cantidad',
    ];

    public function user()
    {
        return $this->belongsTo(Usuario::class);  // Cambiado aquí
    }

    // Obtener el producto asociado según el tipo_producto
    public function producto()
    {
        switch ($this->tipo_producto) {
            case 'camiseta':
                return \App\Models\Camiseta::find($this->producto_id);
            case 'balon':
                return \App\Models\Balon::find($this->producto_id);
            case 'uniforme':
                return \App\Models\Uniforme::find($this->producto_id);
            default:
                return null;
        }
    }
}
