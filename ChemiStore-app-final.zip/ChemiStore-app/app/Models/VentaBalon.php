<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Balon;
use App\Models\DetalleVenta;

class VentaBalon extends Model
{
    protected $table = 'venta_balon';

    protected $fillable = [
        'cantidad',
        'fk_balon',
        'fk_detalle_venta',
    ];

    /**
     * Una venta pertenece a un balón (producto).
     * Si el balón fue eliminado (set null), devuelve objeto por defecto.
     */
    public function balon()
    {
        return $this->belongsTo(Balon::class, 'fk_balon')->withDefault([
            'Marca_balon' => 'Balón eliminado',
            'Tamaño_balon' => '',
            'Tipo_balon' => '',
            'Precio_balon' => 0,
            'imagen_url' => null,
        ]);
    }

    /**
     * Relación con detalle venta.
     */
    public function detalleVenta()
    {
        return $this->belongsTo(DetalleVenta::class, 'fk_detalle_venta');
    }
}
