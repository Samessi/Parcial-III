<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // Mostrar formulario login
    public function showLogin()
    {
        return view('login');
    }

    // Procesar login
    public function login(Request $request)
    {
        $request->validate([
            'Correo' => 'required|email',
            'password' => 'required',
        ]);

        // Intentar login con guard personalizado usando correo y password
        if (Auth::guard('web')->attempt(['Correo' => $request->Correo, 'password' => $request->password])) {
            $request->session()->regenerate();
            return redirect()->intended('/');  // Home u otra ruta protegida
        }

        return back()->withErrors([
            'Correo' => 'Las credenciales no coinciden.',
        ])->onlyInput('Correo');
    }

    // Logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
