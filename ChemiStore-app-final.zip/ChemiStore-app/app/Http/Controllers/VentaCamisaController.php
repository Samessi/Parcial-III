<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Camiseta;

class VentaCamisaController extends Controller
{
    public function index()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $camisetas = Camiseta::all();
        return view('admin.camisetas.index', compact('camisetas'));
    }

    public function create()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        return view('admin.camisetas.create');
    }

    public function store(Request $request)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $camiseta = new Camiseta($request->all());
        $camiseta->save();

        return redirect()->route('admin.camisetas.index')->with('success', 'Camiseta creada correctamente.');
    }

    public function edit($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $camiseta = Camiseta::findOrFail($id);
        return view('admin.camisetas.edit', compact('camiseta'));
    }

    public function update(Request $request, $id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $camiseta = Camiseta::findOrFail($id);
        $camiseta->update($request->all());

        return redirect()->route('admin.camisetas.index')->with('success', 'Camiseta actualizada.');
    }

    public function destroy($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $camiseta = Camiseta::findOrFail($id);
        $camiseta->delete();

        return redirect()->route('admin.camisetas.index')->with('success', 'Camiseta eliminada.');
    }
}
