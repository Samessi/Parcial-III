<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;

class UsuarioController extends Controller
{
    public function create()
    {
        return view('registro');
    }

    public function store(Request $request)
    {
       $request->validate([
    'Nombre' => ['required', 'string', 'max:255'],
    'Apellido' => ['required', 'string', 'max:255'],
    'Telefono' => ['required', 'string', 'max:20'],
    'Correo' => ['required', 'string', 'email', 'max:255', 'unique:users,Correo'],
    'password' => ['required', 'confirmed', 'min:8'],
]);

$user = Usuario::create([
    'Nombre' => $request->Nombre,
    'Apellido' => $request->Apellido,
    'Telefono' => $request->Telefono,
    'Correo' => $request->Correo,
    'password' => Hash::make($request->password),
]);


        // Redirige a login después del registro exitoso
        return redirect()->route('login')->with('success', 'Usuario registrado correctamente. Ahora inicia sesión.');
    }
}
