<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Uniforme;

class VentaUniformesController extends Controller
{
    public function index()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $uniformes = Uniforme::all();
        return view('admin.uniformes.index', compact('uniformes'));
    }

    public function create()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        return view('admin.uniformes.create');
    }

    public function store(Request $request)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $request->validate([
            'Equipo_uniforme' => 'required|string|max:255',
            'Marca_uniforme' => 'required|string|max:255',
            'Tamaño_uniforme' => 'required|string|max:255',
            'Tipo_uniforme' => 'nullable|string|max:255',
            'Precio_uniforme' => 'required|numeric',
            'imagen_url' => 'nullable|string|max:255',
        ]);

        $uniforme = new Uniforme($request->all());
        $uniforme->save();

        return redirect()->route('admin.uniformes.index')->with('success', 'Uniforme creado correctamente.');
    }

    public function edit($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $uniforme = Uniforme::findOrFail($id);
        return view('admin.uniformes.edit', compact('uniforme'));
    }

    public function update(Request $request, $id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $request->validate([
            'Equipo_uniforme' => 'required|string|max:255',
            'Marca_uniforme' => 'required|string|max:255',
            'Tamaño_uniforme' => 'required|string|max:255',
            'Tipo_uniforme' => 'nullable|string|max:255',
            'Precio_uniforme' => 'required|numeric',
            'imagen_url' => 'nullable|string|max:255',
        ]);

        $uniforme = Uniforme::findOrFail($id);
        $uniforme->update($request->all());

        return redirect()->route('admin.uniformes.index')->with('success', 'Uniforme actualizado correctamente.');
    }

    public function destroy($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $uniforme = Uniforme::findOrFail($id);
        $uniforme->delete();

        return redirect()->route('admin.uniformes.index')->with('success', 'Uniforme eliminado correctamente.');
    }
}
