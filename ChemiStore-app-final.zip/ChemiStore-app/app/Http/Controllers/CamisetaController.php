<?php



namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Camiseta;

class CamisetaController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');

        $camisetas = Camiseta::query()
            ->when($search, function($query, $search) {
                $query->where('Equipo_camiseta', 'like', "%{$search}%")
                      ->orWhere('Marca_camiseta', 'like', "%{$search}%")
                      ->orWhere('Tamaño_camiseta', 'like', "%{$search}%")
                      ->orWhere('Tipo_camiseta', 'like', "%{$search}%");
            })
            ->get();

        return view('home', compact('camisetas'));
    }
}
