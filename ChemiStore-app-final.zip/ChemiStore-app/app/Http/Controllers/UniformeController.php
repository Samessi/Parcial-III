<?php

namespace App\Http\Controllers;

use App\Models\Uniforme;
use Illuminate\Http\Request;

class UniformeController extends Controller
{
    public function index(Request $request)
    {
        $query = Uniforme::query();

        if ($request->has('search') && $request->search != '') {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('Equipo_uniforme', 'like', "%$search%")
                  ->orWhere('Marca_uniforme', 'like', "%$search%")
                  ->orWhere('Tipo_uniforme', 'like', "%$search%");
            });
        }

        $uniformes = $query->get();

        return view('uniformes', compact('uniformes'));
    }
}
