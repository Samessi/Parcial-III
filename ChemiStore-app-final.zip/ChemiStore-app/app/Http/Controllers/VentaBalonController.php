<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Balon;

class VentaBalonController extends Controller
{
    public function index()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $balones = Balon::all();
        return view('admin.balones.index', compact('balones'));
    }

    public function create()
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        return view('admin.balones.create');
    }

    public function store(Request $request)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $request->validate([
            'Marca_balon' => 'required|string|max:255',
            'Tamaño_balon' => 'required|integer',
            'Tipo_balon' => 'nullable|string|max:255',
            'Precio_balon' => 'required|numeric',
            'imagen_url' => 'nullable|string|max:255',
        ]);

        $balon = new Balon($request->all());
        $balon->save();

        return redirect()->route('admin.balones.index')->with('success', 'Balón creado correctamente.');
    }

    public function edit($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $balon = Balon::findOrFail($id);
        return view('admin.balones.edit', compact('balon'));
    }

    public function update(Request $request, $id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $request->validate([
            'Marca_balon' => 'required|string|max:255',
            'Tamaño_balon' => 'required|integer',
            'Tipo_balon' => 'nullable|string|max:255',
            'Precio_balon' => 'required|numeric',
            'imagen_url' => 'nullable|string|max:255',
        ]);

        $balon = Balon::findOrFail($id);
        $balon->update($request->all());

        return redirect()->route('admin.balones.index')->with('success', 'Balón actualizado correctamente.');
    }

    public function destroy($id)
    {
        if (auth()->user()->Correo != 'admin@correo.com') {
            abort(403, 'No tienes permiso para acceder');
        }

        $balon = Balon::findOrFail($id);
        $balon->delete();

        return redirect()->route('admin.balones.index')->with('success', 'Balón eliminado correctamente.');
    }
}
