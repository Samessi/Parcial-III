<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use App\Models\Camiseta;
use App\Models\Balon;
use App\Models\Uniforme;
use App\Models\VentaCamisa;
use App\Models\VentaBalon;
use App\Models\VentaUniforme;
use App\Models\DetalleVenta;

class CartController extends Controller
{
    // Agregar producto al carrito
    public function addToCart(Request $request)
    {
        $request->validate([
            'producto_id' => 'required|integer',
            'tipo_producto' => 'required|string',
            'cantidad' => 'required|integer|min:1',
        ]);

        Cart::create([
            'user_id' => Auth::user()->id,
            'producto_id' => $request->producto_id,
            'tipo_producto' => $request->tipo_producto,
            'cantidad' => $request->cantidad,
        ]);

        return redirect()->back()->with('success', 'Producto agregado al carrito.');
    }

    // Ver carrito
    public function viewCart()
    {
        $userId = Auth::id();
        $carrito = Cart::where('user_id', $userId)->get();

        return view('carrito', compact('carrito'));
    }

    // Eliminar un producto del carrito
    public function removeItem($id)
    {
        $item = Cart::findOrFail($id);

        if ($item->user_id !== Auth::id()) {
            abort(403); // No permitido eliminar carrito de otro usuario
        }

        $item->delete();

        return redirect()->route('carrito.ver')->with('success', 'Producto eliminado del carrito.');
    }

    // Vista checkout
    public function checkout()
    {
        $user = Auth::user();
        $carrito = Cart::where('user_id', $user->id)->get();

        if ($carrito->isEmpty()) {
            return redirect()->route('carrito.ver')->with('error', 'Tu carrito está vacío.');
        }

        return view('checkout', compact('carrito'));
    }

    // Finalizar compra
    public function finalizarCompra(Request $request)
    {
        $user = Auth::user();
        $carrito = Cart::where('user_id', $user->id)->get();

        if ($carrito->isEmpty()) {
            return redirect()->route('carrito.ver')->with('error', 'Tu carrito está vacío.');
        }

        // Crear detalle de venta una sola vez
        $detalleVenta = DetalleVenta::create([
            'nombre' => $request->nombre,
            'email' => $request->email,
            'telefono' => $request->telefono,
            'direccion' => $request->direccion,
        ]);

        foreach ($carrito as $item) {
            switch ($item->tipo_producto) {
                case 'camiseta':
                    $producto = Camiseta::find($item->producto_id);
                    if ($producto) {
                        VentaCamisa::create([
                            'fk_camisa' => $producto->id,
                            'cantidad' => $item->cantidad,
                            'fk_detalle_venta' => $detalleVenta->id,
                        ]);
                    }
                    break;

                case 'balon':
                    $producto = Balon::find($item->producto_id);
                    if ($producto) {
                        VentaBalon::create([
                            'fk_balon' => $producto->id,
                            'cantidad' => $item->cantidad,
                            'fk_detalle_venta' => $detalleVenta->id,
                        ]);
                    }
                    break;

                case 'uniforme':
                    $producto = Uniforme::find($item->producto_id);
                    if ($producto) {
                        VentaUniforme::create([
                            'fk_uniforme' => $producto->id,
                            'cantidad' => $item->cantidad,
                            'fk_detalle_venta' => $detalleVenta->id,
                        ]);
                    }
                    break;
            }
        }

        // Vaciar carrito
        Cart::where('user_id', $user->id)->delete();

        return redirect()->route('carrito.ver')->with('success', '¡Compra realizada con éxito!');
    }
}
