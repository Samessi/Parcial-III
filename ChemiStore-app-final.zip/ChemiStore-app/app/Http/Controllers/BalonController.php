<?php



namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Balon;

class BalonController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');

        $balones = Balon::query()
            ->when($search, function($query, $search) {
                $query->where('Marca_balon', 'like', "%{$search}%")
                      ->orWhere('Tipo_balon', 'like', "%{$search}%")
                      ->orWhere('Tamaño_balon', 'like', "%{$search}%");
            })
            ->get();

        return view('balones', compact('balones'));
    }
}
