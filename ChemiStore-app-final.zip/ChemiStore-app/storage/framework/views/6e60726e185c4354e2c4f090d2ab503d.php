<?php $__env->startSection('title', 'Balones - ChemiStore'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .catalogo {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
    .producto {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px;
        width: 220px;
        text-align: center;
        background-color: #f9f9f9;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: transform 0.2s ease-in-out;
    }
    .producto:hover {
        transform: translateY(-5px);
    }
    .producto img {
        width: 100%;       /* que ocupe todo el ancho del contenedor */
        max-width: 250px;  /* tamaño máximo */
        height: 150px;     /* altura fija para que todas sean iguales */
        object-fit: cover; /* recorta y ajusta la imagen sin deformar */
        border-radius: 8px;
        display: block;
        margin: 0 auto 10px auto;
    }
    .producto h3 {
        margin: 0 0 10px 0;
    }
    .producto button {
        margin-top: 10px;
        background-color: black;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        width: 100%;
        transition: background-color 0.3s;
    }
    .producto button:hover {
        background-color: #333;
    }
    form label {
        display: inline-block;
        margin-right: 5px;
        font-weight: bold;
    }
    form input[type=number] {
        width: 50px;
        padding: 3px;
        border: 1px solid #ccc;
        border-radius: 5px;
        text-align: center;
    }
    .filtro-busqueda {
        text-align: center;
        margin-bottom: 20px;
    }
    .filtro-busqueda input[type="text"] {
        padding: 8px;
        width: 250px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 10px;
    }
    .filtro-busqueda button {
        padding: 8px 15px;
        background-color: black;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: background-color 0.3s;
    }
    .filtro-busqueda button:hover {
        background-color: #333;
    }
</style>

<h1>Catálogo de Balones</h1>

<?php if(session('success')): ?>
    <div style="color: green; text-align:center; margin-bottom: 1rem;"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="filtro-busqueda">
    <form method="GET" action="<?php echo e(route('balones')); ?>">
        <input type="text" name="search" placeholder="Buscar balones..." value="<?php echo e(request('search')); ?>">
        <button type="submit">Buscar</button>
    </form>
</div>

<div class="catalogo">
    <?php $__empty_1 = true; $__currentLoopData = $balones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="producto">
            <img src="<?php echo e($balon->imagen_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($balon->Marca_balon); ?>">
            <h3><?php echo e($balon->Marca_balon); ?></h3>
            <p>Tipo: <?php echo e($balon->Tipo_balon ?? 'N/A'); ?></p>
            <p>Tamaño: <?php echo e($balon->Tamaño_balon); ?></p>
            <p class="price">$<?php echo e($balon->Precio_balon); ?></p>

            <form action="<?php echo e(route('carrito.agregar')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="producto_id" value="<?php echo e($balon->id); ?>">
                <input type="hidden" name="tipo_producto" value="balon">

                <label for="cantidad_<?php echo e($balon->id); ?>">Cantidad:</label>
                <input type="number" id="cantidad_<?php echo e($balon->id); ?>" name="cantidad" value="1" min="1">

                <button type="submit">Agregar al carrito</button>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No se encontraron balones.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/balones.blade.php ENDPATH**/ ?>