

<?php $__env->startSection('title', 'Administrar Camisetas'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .catalogo {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
    .producto {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px;
        width: 250px;
        text-align: center;
        background-color: #f9f9f9;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: transform 0.2s ease-in-out;
    }
    .producto:hover {
        transform: translateY(-5px);
    }
    .producto img {
        width: 100%;
        max-width: 250px;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
        display: block;
        margin: 0 auto 10px auto;
    }
    .producto h3 {
        margin: 0 0 10px 0;
    }
    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
        display: inline-block;
    }
    .btn:hover {
        background-color: #333;
    }
    .acciones {
        display: flex;
        flex-direction: column;
        gap: 5px;
        margin-top: 10px;
    }
</style>

<h1>Administrar Camisetas</h1>

<div style="text-align:center; margin-bottom: 20px;">
    <a href="<?php echo e(route('admin.camisetas.create')); ?>" class="btn">Agregar nueva camiseta</a>
</div>

<div class="catalogo">
    <?php $__currentLoopData = $camisetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="producto">
<img src="<?php echo e($c->imagen_url ?? 'https://via.placeholder.com/300x200'); ?>" alt="<?php echo e($c->Marca_camiseta); ?>">
            <h3><?php echo e($c->Equipo_camiseta); ?></h3>
            <p>Marca: <?php echo e($c->Marca_camiseta); ?></p>
            <p>Tamaño: <?php echo e($c->Tamaño_camiseta); ?></p>
            <p>Tipo: <?php echo e($c->Tipo_camiseta); ?></p>
            <p>Precio: $<?php echo e($c->Precio_camiseta); ?></p>

            <div class="acciones">
                <a href="<?php echo e(route('admin.camisetas.edit', $c->id)); ?>" class="btn">Editar</a>
                <form action="<?php echo e(route('admin.camisetas.destroy', $c->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn" onclick="return confirm('¿Seguro que deseas eliminar esta camiseta?')">Eliminar</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/admin/camisetas/index.blade.php ENDPATH**/ ?>