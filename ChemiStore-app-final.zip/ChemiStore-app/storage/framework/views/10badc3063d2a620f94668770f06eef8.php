

<?php $__env->startSection('title', 'Agregar Balón'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }

    form {
        max-width: 500px;
        margin: 0 auto;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    input, select {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
    }

    .btn:hover {
        background-color: #333;
    }

    .btn-secondary {
        background-color: #777;
        margin-left: 10px;
    }

    .btn-secondary:hover {
        background-color: #555;
    }
</style>

<h1>Agregar Balón</h1>

<form action="<?php echo e(route('admin.balones.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label for="Marca_balon">Marca</label>
    <input type="text" name="Marca_balon" id="Marca_balon" required>

    <label for="Tamaño_balon">Tamaño</label>
    <input type="number" name="Tamaño_balon" id="Tamaño_balon" required>

    <label for="Tipo_balon">Tipo</label>
    <input type="text" name="Tipo_balon" id="Tipo_balon">

    <label for="Precio_balon">Precio</label>
    <input type="number" step="0.01" name="Precio_balon" id="Precio_balon" required>

    <label for="imagen_url">URL de la imagen</label>
    <input type="text" name="imagen_url" id="imagen_url">

    <button type="submit" class="btn">Guardar</button>
    <a href="<?php echo e(route('admin.balones.index')); ?>" class="btn btn-secondary">Cancelar</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/admin/balones/create.blade.php ENDPATH**/ ?>