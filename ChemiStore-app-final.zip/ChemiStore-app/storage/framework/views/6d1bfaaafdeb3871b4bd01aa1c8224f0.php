

<?php $__env->startSection('title', 'Editar Camiseta'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .form-container {
        max-width: 500px;
        margin: 0 auto;
        background-color: #f9f9f9;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .form-container label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    .form-container input,
    .form-container select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
    }
    .form-container button {
        background-color: black;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        width: 100%;
        transition: background-color 0.3s;
    }
    .form-container button:hover {
        background-color: #333;
    }
</style>

<h1>Editar Camiseta</h1>

<div class="form-container">
    <form action="<?php echo e(route('admin.camisetas.update', $camiseta->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="Equipo_camiseta">Equipo</label>
        <input type="text" name="Equipo_camiseta" value="<?php echo e($camiseta->Equipo_camiseta); ?>" required>

        <label for="Marca_camiseta">Marca</label>
        <input type="text" name="Marca_camiseta" value="<?php echo e($camiseta->Marca_camiseta); ?>" required>

        <label for="Tamaño_camiseta">Tamaño</label>
        <input type="text" name="Tamaño_camiseta" value="<?php echo e($camiseta->Tamaño_camiseta); ?>" required>

        <label for="Tipo_camiseta">Tipo</label>
        <input type="text" name="Tipo_camiseta" value="<?php echo e($camiseta->Tipo_camiseta); ?>">

        <label for="Precio_camiseta">Precio</label>
        <input type="number" name="Precio_camiseta" value="<?php echo e($camiseta->Precio_camiseta); ?>" required step="0.01">

        <label for="imagen_url">Imagen (opcional)</label>
        <input type="text" name="imagen_url" placeholder="https://ejemplo.com/imagen.jpg" required>

    
        <button type="submit">Actualizar Camiseta</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/admin/camisetas/edit.blade.php ENDPATH**/ ?>