

<?php $__env->startSection('title', 'Registro - ChemiStore'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .registro-container {
        max-width: 400px;
        margin: 0 auto;
        background: #f9f9f9;
        padding: 30px 25px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    form label {
        display: block;
        margin-bottom: 6px;
        font-weight: bold;
        color: #333;
    }
    form input[type="text"],
    form input[type="email"],
    form input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1rem;
        box-sizing: border-box;
    }
    form button {
        background-color: black;
        color: white;
        border: none;
        padding: 12px 25px;
        font-size: 1.1rem;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        transition: background-color 0.3s;
    }
    form button:hover {
        background-color: #333;
    }
    .login-link {
        display: block;
        margin-top: 15px;
        text-align: center;
        font-size: 0.9rem;
        color: #555;
        text-decoration: none;
    }
    .login-link:hover {
        text-decoration: underline;
    }
    .error-message {
        color: #e91e63;
        font-size: 0.9rem;
        margin-bottom: 10px;
    }
</style>

<h1>Crear una cuenta</h1>

<div class="registro-container">
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <label for="Nombre">Nombre</label>
        <input id="Nombre" type="text" name="Nombre" value="<?php echo e(old('Nombre')); ?>" required autofocus>
        <?php $__errorArgs = ['Nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="Apellido">Apellido</label>
        <input id="Apellido" type="text" name="Apellido" value="<?php echo e(old('Apellido')); ?>" required>
        <?php $__errorArgs = ['Apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="Telefono">Teléfono</label>
        <input id="Telefono" type="text" name="Telefono" value="<?php echo e(old('Telefono')); ?>" required>
        <?php $__errorArgs = ['Telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="Correo">Correo electrónico</label>
        <input id="Correo" type="email" name="Correo" value="<?php echo e(old('Correo')); ?>" required>
        <?php $__errorArgs = ['Correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password">Contraseña</label>
        <input id="password" type="password" name="password" required>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password_confirmation">Confirmar contraseña</label>
        <input id="password_confirmation" type="password" name="password_confirmation" required>

        <button type="submit">Registrarse</button>
    </form>

    <a href="<?php echo e(route('login')); ?>" class="login-link">¿Ya tienes cuenta? Inicia sesión</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/registro.blade.php ENDPATH**/ ?>