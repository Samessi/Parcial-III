

<?php $__env->startSection('title', 'Agregar Uniforme'); ?>

<?php $__env->startSection('content'); ?>
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }

    form {
        max-width: 500px;
        margin: 0 auto;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    input, select {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
    }

    .btn:hover {
        background-color: #333;
    }

    .btn-secondary {
        background-color: #777;
        margin-left: 10px;
    }

    .btn-secondary:hover {
        background-color: #555;
    }
</style>

<h1>Agregar Uniforme</h1>

<form action="<?php echo e(route('admin.uniformes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label for="Equipo_uniforme">Equipo</label>
    <input type="text" name="Equipo_uniforme" id="Equipo_uniforme" required>

    <label for="Marca_uniforme">Marca</label>
    <input type="text" name="Marca_uniforme" id="Marca_uniforme" required>

    <label for="Tamaño_uniforme">Tamaño</label>
    <input type="text" name="Tamaño_uniforme" id="Tamaño_uniforme" required>

    <label for="Tipo_uniforme">Tipo</label>
    <input type="text" name="Tipo_uniforme" id="Tipo_uniforme">

    <label for="Precio_uniforme">Precio</label>
    <input type="number" step="0.01" name="Precio_uniforme" id="Precio_uniforme" required>

    <label for="imagen_url">URL de la imagen</label>
    <input type="text" name="imagen_url" id="imagen_url">

    <button type="submit" class="btn">Guardar</button>
    <a href="<?php echo e(route('admin.uniformes.index')); ?>" class="btn btn-secondary">Cancelar</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/admin/uniformes/create.blade.php ENDPATH**/ ?>