

<?php $__env->startSection('title', 'Iniciar Sesión'); ?>

<?php $__env->startSection('content'); ?>
<style>
  /* Aquí van los estilos del formulario login que ya tienes */
  h1 {
    text-align: center;
    margin: 1.5rem 0;
  }
  form.login-form {
    max-width: 400px;
    margin: 0 auto;
    background-color: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  }
  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
    color: #333;
  }
  input[type="email"],
  input[type="password"] {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 1.2rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 1rem;
  }
  .btn-login {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s;
    width: 100%;
  }
  .btn-login:hover {
    background-color: #0056b3;
  }
  .mensaje {
    max-width: 400px;
    margin: 1rem auto;
    padding: 1rem;
    border-radius: 10px;
    font-weight: bold;
    text-align: center;
  }
  .error {
    background-color: #f8d7da;
    color: #721c24;
  }
  .register-link {
    text-align: center;
    margin-top: 1rem;
  }
  .register-link a {
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
  }
  .register-link a:hover {
    text-decoration: underline;
  }
</style>

<h1>Iniciar Sesión</h1>

<?php if($errors->any()): ?>
  <div class="mensaje error">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<form action="<?php echo e(route('login')); ?>" method="POST" class="login-form">
  <?php echo csrf_field(); ?>
  <label for="Correo">Correo Electrónico</label>
<input type="email" id="Correo" name="Correo" required value="<?php echo e(old('Correo')); ?>">


  <label for="password">Contraseña</label>
  <input type="password" id="password" name="password" required>

  <button type="submit" class="btn-login">Entrar</button>
</form>

<div class="register-link">
  <p>¿No tienes cuenta? <a href="<?php echo e(route('register')); ?>">Regístrate</a></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Messito\Downloads\ChemiStore-app\ChemiStore-app\resources\views/login.blade.php ENDPATH**/ ?>