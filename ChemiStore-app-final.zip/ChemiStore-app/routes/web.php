<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CamisetaController;
use App\Http\Controllers\BalonController;
use App\Http\Controllers\UniformeController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\VentaCamisaController;
use App\Http\Controllers\VentaBalonController;
use App\Http\Controllers\VentaUniformesController;
use App\Http\Controllers\CartController;

// Rutas públicas
Route::get('/', [CamisetaController::class, 'index'])->name('home');
Route::get('/balones', [BalonController::class, 'index'])->name('balones');
Route::get('/uniformes', [UniformeController::class, 'index'])->name('uniformes');

Route::get('/register', [UsuarioController::class, 'create'])->name('register');
Route::post('/register', [UsuarioController::class, 'store']);

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Rutas protegidas por autenticación
Route::middleware('auth')->group(function () {

    // Carrito
    Route::get('/carrito', [CartController::class, 'viewCart'])->name('carrito.ver');
    Route::post('/carrito/agregar', [CartController::class, 'addToCart'])->name('carrito.agregar');
    Route::post('/carrito/eliminar/{id}', [CartController::class, 'removeItem'])->name('carrito.eliminar');
    Route::get('/carrito/checkout', [CartController::class, 'checkout'])->name('carrito.checkout');
    Route::post('/carrito/checkout/finalizar', [CartController::class, 'finalizarCompra'])->name('carrito.finalizar');

    // CRUD para camisetas (modo administrador)
    Route::prefix('admin/camisetas')->name('admin.camisetas.')->group(function () {
        Route::get('/', [VentaCamisaController::class, 'index'])->name('index');
        Route::get('/crear', [VentaCamisaController::class, 'create'])->name('create');
        Route::post('/', [VentaCamisaController::class, 'store'])->name('store');
        Route::get('/{id}/editar', [VentaCamisaController::class, 'edit'])->name('edit');
        Route::put('/{id}', [VentaCamisaController::class, 'update'])->name('update');
        Route::delete('/{id}', [VentaCamisaController::class, 'destroy'])->name('destroy');
    });


   // Rutas para Balones
Route::prefix('admin/balones')->name('admin.balones.')->group(function () {
    Route::get('/', [VentaBalonController::class, 'index'])->name('index');
    Route::get('/create', [VentaBalonController::class, 'create'])->name('create');
    Route::post('/', [VentaBalonController::class, 'store'])->name('store');
    Route::get('/{balon}/edit', [VentaBalonController::class, 'edit'])->name('edit');
    Route::put('/{balon}', [VentaBalonController::class, 'update'])->name('update');
    Route::delete('/{balon}', [VentaBalonController::class, 'destroy'])->name('destroy');
});

// Rutas para Uniformes
Route::prefix('admin/uniformes')->name('admin.uniformes.')->group(function () {
    Route::get('/', [VentaUniformesController::class, 'index'])->name('index');
    Route::get('/create', [VentaUniformesController::class, 'create'])->name('create');
    Route::post('/', [VentaUniformesController::class, 'store'])->name('store');
    Route::get('/{uniforme}/edit', [VentaUniformesController::class, 'edit'])->name('edit');
    Route::put('/{uniforme}', [VentaUniformesController::class, 'update'])->name('update');
    Route::delete('/{uniforme}', [VentaUniformesController::class, 'destroy'])->name('destroy');
});
});