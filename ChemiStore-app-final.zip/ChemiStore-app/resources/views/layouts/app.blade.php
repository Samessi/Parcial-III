<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>@yield('title') - ChemiStore</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        header {
            background-color: #222;
            color: white;
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .nav-left {
            position: absolute;
            left: 1rem;
        }
        .nav-left a {
            text-decoration: none;
            margin-right: 10px;
            background-color: #000;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
            font-weight: bold;
        }
        .nav-left a:hover {
            background-color: #333;
        }
        .title {
            margin: 0;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .nav-right {
            position: absolute;
            right: 1rem;
        }
        .nav-right a,
        .nav-right form button {
            background-color: #000;
            color: white;
            padding: 8px 18px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            transition: background 0.3s;
            font-size: 0.9rem;
        }
        .nav-right a:hover,
        .nav-right form button:hover {
            background-color: #333;
        }
        main {
            padding: 1rem 2rem;
        }
        footer {
            text-align: center;
            margin-top: 2rem;
            padding: 1rem;
            background-color: #222;
            color: white;
        }
    </style>
</head>
<body>

<header>
    <div class="nav-left">
        <a href="{{ route('home') }}">Inicio</a>
        <a href="{{ route('balones') }}">Balones</a>
        <a href="{{ route('uniformes') }}">Uniformes</a>
        <a href="{{ route('carrito.ver') }}">Carrito</a>
    </div>

    <h1 class="title">ChemiStore</h1>

    <div class="nav-right">
        @auth
            <form action="{{ route('logout') }}" method="POST" style="display:inline;">
                @csrf
                <button type="submit">Cerrar sesión</button>
            </form>
        @else
            <a href="{{ route('login') }}">Iniciar sesión</a>
        @endauth
    </div>
</header>

<main>
    @yield('content')
</main>

<footer>
    &copy; {{ date('Y') }} ChemiStore. Todos los derechos reservados.
</footer>

</body>
</html>
