@extends('layouts.app')

@section('title', 'Checkout - ChemiStore')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .checkout-container {
        max-width: 600px;
        margin: 0 auto;
        background: #f9f9f9;
        padding: 30px 25px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    form label {
        display: block;
        margin-bottom: 6px;
        font-weight: bold;
        color: #333;
    }
    form input[type="text"],
    form input[type="email"],
    form input[type="tel"],
    form textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1rem;
        box-sizing: border-box;
        resize: vertical;
    }
    form button {
        background-color: black;
        color: white;
        border: none;
        padding: 12px 25px;
        font-size: 1.1rem;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        transition: background-color 0.3s;
    }
    form button:hover {
        background-color: #333;
    }
    .back-link {
        display: inline-block;
        margin-top: 15px;
        color: #555;
        text-decoration: none;
        font-size: 0.9rem;
    }
    .back-link:hover {
        text-decoration: underline;
    }
</style>

<h1>Finalizar Compra</h1>

@if($carrito->count() > 0)

<div class="checkout-container">
    <form action="{{ route('carrito.finalizar') }}" method="POST">

        @csrf

        <label for="nombre">Nombre Completo</label>
        <input type="text" id="nombre" name="nombre" required placeholder="Tu nombre completo">

        <label for="email">Correo Electrónico</label>
        <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com">

        <label for="telefono">Teléfono</label>
        <input type="tel" id="telefono" name="telefono" required placeholder="Tu número de teléfono">

        <label for="direccion">Dirección de Envío</label>
        <textarea id="direccion" name="direccion" rows="3" required placeholder="Dirección completa"></textarea>

        <button type="submit">Confirmar Compra</button>
    </form>
    <a href="{{ route('carrito.ver') }}" class="back-link">← Volver al carrito</a>
</div>
@else
    <p style="text-align:center; font-size:1.2rem; color:#555;">Tu carrito está vacío. <a href="{{ route('home') }}">Ver productos</a></p>
@endif
@endsection
