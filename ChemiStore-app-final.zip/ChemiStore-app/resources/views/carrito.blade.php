@extends('layouts.app')

@section('title', 'Carrito - ChemiStore')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .carrito-container {
        max-width: 900px;
        margin: 0 auto;
        background: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }
    th, td {
        padding: 12px 15px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: black;
        color: white;
    }
    tbody tr:hover {
        background-color: #f1f1f1;
    }
    .btn-eliminar {
        background-color: #e91e63;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .btn-eliminar:hover {
        background-color: #c2185b;
    }
    .total {
        font-weight: bold;
        font-size: 1.2rem;
        text-align: right;
        margin-bottom: 20px;
    }
    .btn-checkout {
        background-color: black;
        color: white;
        border: none;
        padding: 12px 25px;
        font-size: 1rem;
        border-radius: 5px;
        cursor: pointer;
        float: right;
        transition: background-color 0.3s;
    }
    .btn-checkout:hover {
        background-color: #333;
    }
    .empty-message {
        text-align: center;
        font-size: 1.2rem;
        color: #555;
        padding: 40px 0;
    }
</style>

<h1>Tu Carrito de Compras</h1>

<div class="carrito-container">
    @if($carrito->count() > 0)
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Tipo</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Subtotal</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                @php $total = 0; @endphp
                @foreach($carrito as $item)
                    @php
                        switch ($item->tipo_producto) {
                            case 'camiseta':
                                $producto = \App\Models\Camiseta::find($item->producto_id);
                                $nombre = $producto ? $producto->Equipo_camiseta : 'Camiseta';
                                $precio = $producto ? $producto->Precio_camiseta : 0;
                                break;
                            case 'balon':
                                $producto = \App\Models\Balon::find($item->producto_id);
                                $nombre = $producto ? $producto->Tipo_balon : 'Balón';
                                $precio = $producto ? $producto->Precio_balon : 0;
                                break;
                            case 'uniforme':
                                $producto = \App\Models\Uniforme::find($item->producto_id);
                                $nombre = $producto ? $producto->Equipo_uniforme : 'Uniforme';
                                $precio = $producto ? $producto->Precio_uniforme : 0;
                                break;
                            default:
                                $nombre = 'Producto';
                                $precio = 0;
                        }
                        $subtotal = $precio * $item->cantidad;
                        $total += $subtotal;
                    @endphp
                    <tr>
                        <td>{{ $nombre }}</td>
                        <td>{{ ucfirst($item->tipo_producto) }}</td>
                        <td>{{ $item->cantidad }}</td>
                        <td>${{ number_format($precio, 2) }}</td>
                        <td>${{ number_format($subtotal, 2) }}</td>
                        <td>
                            <form action="{{ route('carrito.eliminar', $item->id) }}" method="POST">
                                @csrf
                                <button class="btn-eliminar" type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="total">Total: ${{ number_format($total, 2) }}</div>

        <a href="{{ route('carrito.checkout') }}" class="btn-checkout">Proceder al pago</a>
    @else
        <div class="empty-message">Tu carrito está vacío.</div>
    @endif
</div>
@endsection
