@extends('layouts.app')

@section('title', 'Registro - ChemiStore')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .registro-container {
        max-width: 400px;
        margin: 0 auto;
        background: #f9f9f9;
        padding: 30px 25px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    form label {
        display: block;
        margin-bottom: 6px;
        font-weight: bold;
        color: #333;
    }
    form input[type="text"],
    form input[type="email"],
    form input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1rem;
        box-sizing: border-box;
    }
    form button {
        background-color: black;
        color: white;
        border: none;
        padding: 12px 25px;
        font-size: 1.1rem;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        transition: background-color 0.3s;
    }
    form button:hover {
        background-color: #333;
    }
    .login-link {
        display: block;
        margin-top: 15px;
        text-align: center;
        font-size: 0.9rem;
        color: #555;
        text-decoration: none;
    }
    .login-link:hover {
        text-decoration: underline;
    }
    .error-message {
        color: #e91e63;
        font-size: 0.9rem;
        margin-bottom: 10px;
    }
</style>

<h1>Crear una cuenta</h1>

<div class="registro-container">
    <form method="POST" action="{{ route('register') }}">
        @csrf

        <label for="Nombre">Nombre</label>
        <input id="Nombre" type="text" name="Nombre" value="{{ old('Nombre') }}" required autofocus>
        @error('Nombre')
            <div class="error-message">{{ $message }}</div>
        @enderror

        <label for="Apellido">Apellido</label>
        <input id="Apellido" type="text" name="Apellido" value="{{ old('Apellido') }}" required>
        @error('Apellido')
            <div class="error-message">{{ $message }}</div>
        @enderror

        <label for="Telefono">Teléfono</label>
        <input id="Telefono" type="text" name="Telefono" value="{{ old('Telefono') }}" required>
        @error('Telefono')
            <div class="error-message">{{ $message }}</div>
        @enderror

        <label for="Correo">Correo electrónico</label>
        <input id="Correo" type="email" name="Correo" value="{{ old('Correo') }}" required>
        @error('Correo')
            <div class="error-message">{{ $message }}</div>
        @enderror

        <label for="password">Contraseña</label>
        <input id="password" type="password" name="password" required>
        @error('password')
            <div class="error-message">{{ $message }}</div>
        @enderror

        <label for="password_confirmation">Confirmar contraseña</label>
        <input id="password_confirmation" type="password" name="password_confirmation" required>

        <button type="submit">Registrarse</button>
    </form>

    <a href="{{ route('login') }}" class="login-link">¿Ya tienes cuenta? Inicia sesión</a>
</div>
@endsection
