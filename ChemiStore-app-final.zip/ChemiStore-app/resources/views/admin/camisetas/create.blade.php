@extends('layouts.app')

@section('title', 'Crear Camiseta')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .form-container {
        max-width: 500px;
        margin: 0 auto;
        background-color: #f9f9f9;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .form-container label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    .form-container input,
    .form-container select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
    }
    .form-container button {
        background-color: black;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        width: 100%;
        transition: background-color 0.3s;
    }
    .form-container button:hover {
        background-color: #333;
    }
</style>

<h1>Agregar Nueva Camiseta</h1>

<div class="form-container">
    <form action="{{ route('admin.camisetas.store') }}" method="POST">
        @csrf

        <label for="Equipo_camiseta">Equipo</label>
        <input type="text" name="Equipo_camiseta" required>

        <label for="Marca_camiseta">Marca</label>
        <input type="text" name="Marca_camiseta" required>

        <label for="Tamaño_camiseta">Tamaño</label>
        <input type="text" name="Tamaño_camiseta" required>

        <label for="Tipo_camiseta">Tipo</label>
        <input type="text" name="Tipo_camiseta">

        <label for="Precio_camiseta">Precio</label>
        <input type="number" name="Precio_camiseta" required step="0.01">

        <label for="imagen_url">URL de la Imagen</label>
        <input type="text" name="imagen_url" placeholder="https://ejemplo.com/imagen.jpg" required>

        <button type="submit">Guardar Camiseta</button>
    </form>
</div>
@endsection
