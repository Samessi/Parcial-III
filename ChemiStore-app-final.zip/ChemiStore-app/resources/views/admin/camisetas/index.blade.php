@extends('layouts.app')

@section('title', 'Administrar Camisetas')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .catalogo {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
    .producto {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px;
        width: 250px;
        text-align: center;
        background-color: #f9f9f9;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: transform 0.2s ease-in-out;
    }
    .producto:hover {
        transform: translateY(-5px);
    }
    .producto img {
        width: 100%;
        max-width: 250px;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
        display: block;
        margin: 0 auto 10px auto;
    }
    .producto h3 {
        margin: 0 0 10px 0;
    }
    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
        display: inline-block;
    }
    .btn:hover {
        background-color: #333;
    }
    .acciones {
        display: flex;
        flex-direction: column;
        gap: 5px;
        margin-top: 10px;
    }
</style>

<h1>Administrar Camisetas</h1>

<div style="text-align:center; margin-bottom: 20px;">
    <a href="{{ route('admin.camisetas.create') }}" class="btn">Agregar nueva camiseta</a>
</div>

<div class="catalogo">
    @foreach($camisetas as $c)
        <div class="producto">
<img src="{{ $c->imagen_url ?? 'https://via.placeholder.com/300x200' }}" alt="{{ $c->Marca_camiseta }}">
            <h3>{{ $c->Equipo_camiseta }}</h3>
            <p>Marca: {{ $c->Marca_camiseta }}</p>
            <p>Tamaño: {{ $c->Tamaño_camiseta }}</p>
            <p>Tipo: {{ $c->Tipo_camiseta }}</p>
            <p>Precio: ${{ $c->Precio_camiseta }}</p>

            <div class="acciones">
                <a href="{{ route('admin.camisetas.edit', $c->id) }}" class="btn">Editar</a>
                <form action="{{ route('admin.camisetas.destroy', $c->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn" onclick="return confirm('¿Seguro que deseas eliminar esta camiseta?')">Eliminar</button>
                </form>
            </div>
        </div>
    @endforeach
</div>
@endsection
