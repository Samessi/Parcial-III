@extends('layouts.app')

@section('title', 'Administrar Uniformes')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .catalogo {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
    .producto {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px;
        width: 250px;
        text-align: center;
        background-color: #f9f9f9;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: transform 0.2s ease-in-out;
    }
    .producto:hover {
        transform: translateY(-5px);
    }
    .producto img {
        width: 100%;
        max-width: 250px;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
        display: block;
        margin: 0 auto 10px auto;
    }
    .producto h3 {
        margin: 0 0 10px 0;
    }
    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 8px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
        display: inline-block;
    }
    .btn:hover {
        background-color: #333;
    }
    .acciones {
        display: flex;
        flex-direction: column;
        gap: 5px;
        margin-top: 10px;
    }
</style>

<h1>Administrar Uniformes</h1>

<div style="text-align:center; margin-bottom: 20px;">
    <a href="{{ route('admin.uniformes.create') }}" class="btn">Agregar nuevo uniforme</a>
</div>

<div class="catalogo">
    @foreach($uniformes as $u)
        <div class="producto">
            <img src="{{ $u->imagen_url ?? 'https://via.placeholder.com/300x200' }}" alt="{{ $u->Marca_uniforme }}">
            <h3>{{ $u->Equipo_uniforme }}</h3>
            <p>Marca: {{ $u->Marca_uniforme }}</p>
            <p>Tamaño: {{ $u->Tamaño_uniforme }}</p>
            <p>Tipo: {{ $u->Tipo_uniforme }}</p>
            <p>Precio: ${{ $u->Precio_uniforme }}</p>

            <div class="acciones">
                <a href="{{ route('admin.uniformes.edit', $u->id) }}" class="btn">Editar</a>
                <form action="{{ route('admin.uniformes.destroy', $u->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn" onclick="return confirm('¿Seguro que deseas eliminar este uniforme?')">Eliminar</button>
                </form>
            </div>
        </div>
    @endforeach
</div>
@endsection
