@extends('layouts.app')

@section('title', 'Editar Balón')

@section('content')
<style>
    h1 {
        text-align: center;
        margin-bottom: 1.5rem;
    }

    form {
        max-width: 500px;
        margin: 0 auto;
        background-color: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    input, select {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .btn {
        background-color: black;
        color: white;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: background-color 0.3s;
        text-decoration: none;
    }

    .btn:hover {
        background-color: #333;
    }

    .btn-secondary {
        background-color: #777;
        margin-left: 10px;
    }

    .btn-secondary:hover {
        background-color: #555;
    }
</style>

<h1>Editar Balón</h1>

<form action="{{ route('admin.balones.update', $balon->id) }}" method="POST">
    @csrf
    @method('PUT')

    <label for="Marca_balon">Marca</label>
    <input type="text" name="Marca_balon" id="Marca_balon" value="{{ $balon->Marca_balon }}" required>

    <label for="Tamaño_balon">Tamaño</label>
    <input type="number" name="Tamaño_balon" id="Tamaño_balon" value="{{ $balon->Tamaño_balon }}" required>

    <label for="Tipo_balon">Tipo</label>
    <input type="text" name="Tipo_balon" id="Tipo_balon" value="{{ $balon->Tipo_balon }}">

    <label for="Precio_balon">Precio</label>
    <input type="number" step="0.01" name="Precio_balon" id="Precio_balon" value="{{ $balon->Precio_balon }}" required>

    <label for="imagen_url">URL de la imagen</label>
    <input type="text" name="imagen_url" id="imagen_url" value="{{ $balon->imagen_url }}">

    <button type="submit" class="btn">Actualizar</button>
    <a href="{{ route('admin.balones.index') }}" class="btn btn-secondary">Cancelar</a>
</form>
@endsection
